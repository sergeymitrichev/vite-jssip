import fs from "fs";
import path from "path";
import {attachScopes, createFilter, makeLegalIdentifier} from "@rollup/pluginutils";
import {walk} from "estree-walker";
import MagicString from "magic-string";
import is_reference from "is-reference";

const HELPERS = `
export function staticRequire(f, e) {
    return f.__esModule ? f : (f.m || (f.m = {exports: e = {}}, f(e, f.m)), f.m.exports);
}
export function dynamicRequire(mod) {
    if (typeof require !== "undefined") return require(mod);
    throw new Error("dynamic require('" + mod + "') not supported");
}
export function fromESM(e) {
    if (e.__esModule) return e;
    if (typeof e == "object" && typeof e.default == "function") {
        var o = function() { return e.default.apply(this, arguments); };
        o.prototype = e.default.prototype;
    } else o = {__proto__: null};
    Object.defineProperty(o, "__esModule", {value: true});
    Object.keys(e).forEach(function(k) {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(o, k, d.get ? d : {
            enumerable: true,
            get: function() { return e[k]; }
        });
    });
    return o;
}
`;

function node_builtins() {
    return `
        _http_agent _http_client _http_common _http_incoming _http_outgoing _http_server
        _stream_duplex _stream_passthrough _stream_readable _stream_transform _stream_wrap
        _stream_writable _tls_common _tls_wrap assert async_hooks buffer child_process cluster
        console constants crypto dgram diagnostics_channel dns domain events fs http http2 https
        inspector module net os path perf_hooks process punycode querystring readline repl stream
        string_decoder sys timers tls trace_events tty url util v8 vm wasi worker_threads zlib
    `.split(/\s+/).filter(x => x);
}

export default function cjs(options = {}) {
    // Plugin options are similar to @rollup/plugin-commonjs
    // although some defaults differ to simplify typical use.
    options = {
        builtins: node_builtins(),
        extensions: [".mjs", ".js", ".cjs"],
        ignore: ["fsevents"],
        ignoreDynamicRequires: false,
        transformMixedEsModules: true,
        ...options
    };
    // Note: The \x00 character is avoided in wrap as it would break sourcemaps of
    // CommonJS files due to the transform/load algorithm employed by this plugin.
    const wrap = id => `${id}?cjs`, unwrap = (id, r) => (r = /^(.+)\?cjs$/.exec(id)) && r[1];
    const haswrap = unwrap;
    const CJS = "CJS_", ID_HELPERS = "\0" + CJS + "?helpers", SYNEXP = "__E$";
    const filter = createFilter(options.include, options.exclude);
    const isJsonOrBuiltin = mod => mod.endsWith(".json") || options.builtins.includes(mod);
    let obj, from_esm = null, ignore = options.ignore || (() => false);
    if (typeof ignore == "string") ignore = [ignore];
    const requireIgnore = Array.isArray(ignore) ? mod => ignore.includes(mod) : ignore;
    const defMap = new Map;
    return obj = {
        name: "strict-cjs",
        async resolveId(id, importer) {
            if (id == ID_HELPERS || defMap.has(id)) return id;
            const unwrappedId = unwrap(id);
            const res = await this.resolve(unwrappedId || id,
                unwrap(importer) || importer, {skipSelf: true});
            if (res) return unwrappedId ? wrap(res.id) : res.id;
        },
        load(id) {
            if (id == ID_HELPERS) return HELPERS;
            const unwrappedId = unwrap(id) || id;
            if (!defMap.has(unwrappedId)) {
                // Some sources must be loaded and transformed directly because
                // their ?cjs definitions are needed.
                const code = fs.readFileSync(unwrappedId, "utf8");
                const transformed = obj.transform.call(this, code, unwrappedId);
                if (haswrap(id)) {
                    // A ?cjs require wrapper has been requested but not found in the
                    // definition cache after the transform above so it must be an ESM
                    // module, and as result, a CJS trampoline is provided.
                    return defMap.has(id) ? code
                        : `import * as ${CJS}helpers from "${ID_HELPERS}";\n`
                        + `import * as mod from "${unwrappedId}";\n`
                        + (from_esm = `export default /*@__PURE__*/ ${CJS}helpers.fromESM(mod);\n`);
                }
                // Provide the ES trampoline code if present.
                if (transformed && transformed.syntheticNamedExports === SYNEXP) return transformed;
            }
        },
        transform(code, id) {
            if (defMap.has(id)) return defMap.get(id);
            const extName = path.extname(id);
            if (!filter(id) || !options.extensions.includes(extName)) return;
            const ast = this.parse(code);
            const isESM = ast.body.some(node => /^(Export|Import)/.test(node.type));
            const out = new MagicString(code);
            const potentialConflicts = new Set, requireNodes = new Map, requiredModules = new Map;
            let hasModule = false, hasExports = false;
            let hasRequire = false, hasDynamicRequire = false;
            let header = "", footer = "";
            const cjsIdentifiers = ["exports", "module", "require"];
            if (!isESM || options.transformMixedEsModules) {
                let scope = attachScopes(ast, "scope");
                const isGlobalRef = (name, node, parent) =>
                    name == node.name && is_reference(node, parent) && !scope.contains(name);
                // First pass: identify variables and potential conflicts across all scopes.
                walk(ast, {
                    enter(node, parent) {
                        if (node.scope) scope = node.scope;
                        if (node.type == "Identifier" && is_reference(node, parent)) {
                            if (cjsIdentifiers.includes(node.name) && !scope.contains(node.name)) {
                                switch (node.name) {
                                  case "module":
                                    hasModule = true;
                                    break;
                                  case "exports":
                                    hasExports = true;
                                    break;
                                  case "require":
                                    hasRequire = true;
                                    if (!options.ignoreDynamicRequires) {
                                        requireNodes.set(node, parent);
                                    }
                                    break;
                                }
                            }
                            // Only CJS prefixed variable names need be deconflicted.
                            if (node.name.startsWith(CJS)) potentialConflicts.add(node.name);
                        }
                    },
                    leave(node) {
                        if (node.scope) scope = scope.parent;
                    }
                });
                // Second pass: identify calls to require().
                // A separate pass is needed for deconflict() to work correctly.
                walk(ast, {
                    enter(node, parent) {
                        if (node.scope) scope = node.scope;
                        if (node.type == "CallExpression") {
                            let arg0, mod;
                            if (node.callee.type == "Identifier"
                              && isGlobalRef("require", node.callee, node)
                              && node.arguments.length == 1
                              && (arg0 = node.arguments[0]).type == "Literal"
                              && typeof (mod = arg0.value) == "string"
                              && !requireIgnore(mod) && !mod.endsWith(".node")) {
                                const modVar = deconflict(mod);
                                requiredModules.set(mod, modVar);
                                if (!options.ignoreDynamicRequires) {
                                    requireNodes.delete(node.callee);
                                }
                                out.overwrite(node.start, node.end, isJsonOrBuiltin(mod)
                                    ? modVar : `${CJS}helpers.staticRequire(${modVar})`);
                            }
                        }
                    },
                    leave(node) {
                        if (node.scope) scope = scope.parent;
                    }
                });

                // Generate imports for commonjs and JSON modules.
                requiredModules.forEach((modVar, mod) => {
                    const source = isJsonOrBuiltin(mod) ? mod : wrap(mod);
                    header += `import ${modVar} from "${source}";\n`;
                });

                // Optionally generate dynamic requires for non-static uses of require.
                if (!options.ignoreDynamicRequires) requireNodes.forEach((parent, node) => {
                    hasDynamicRequire = true;
                    if (parent.type === 'Property' && parent.shorthand)
                        out.appendRight(node.end, `: ${CJS}helpers.dynamicRequire`);
                    else
                        out.overwrite(node.start, node.end, `${CJS}helpers.dynamicRequire`);
                });
            }
            if (!isESM) {
                // This could be a CJS module or an ESM module without imports and exports,
                // but leave code as is if it's an entry point with no cjs identifiers as
                // an optimization.  Non-entry points cannot be optimized due to possible
                // commonjs module ordering side effects.
                const info = this.getModuleInfo(id);
                if (info && info.isEntry && !hasModule && !hasExports && !hasRequire) return;

                // Surround commonjs code with a function wrapper.
                const cjsWrapperName = deconflict(path.relative(process.cwd(), id));
                header += `function ${cjsWrapperName}(exports${hasModule ? ", module" : ""}) {\n`;
                footer += `\n}\nexport default ${cjsWrapperName};\n`;
            }

            // Either an ESM or CJS module is being transformed at this point.
            if (requiredModules.size || hasDynamicRequire) {
                // Generate a cjs helper import if require calls were found.
                const cjsHelperAlias = deconflict("helpers");
                header = `import * as ${cjsHelperAlias} from "${ID_HELPERS}";\n` + header;
            }
            out.prepend(header).append(footer);

            if (isESM) {
                // Return ES module code that may or may not have transformed requires.
                const transformedCode = out.toString();
                return transformedCode === code ? null : {
                    code: transformedCode,
                    map: options.sourceMap !== false ? out.generateMap() : null,
                };
            }

            // Beyond this point we're dealing with a commonjs module.
            // The actual commonjs code will be cached for future retrieval
            // with a ?cjs suffix by the load method.
            const cjsDef = wrap(id);
            defMap.set(cjsDef, {
                code: out.toString(),
                map: options.sourceMap !== false ? out.generateMap() : null,
                syntheticNamedExports: "default",
            });

            // Return an ES trampoline instead of the commonjs code.
            // This is necessary to preserve the ?cjs module initialization order
            // imposed by require().
            return {
                code: `import * as ${CJS}helpers from "${ID_HELPERS}";\n`
                    + `import cjs from "${cjsDef}";\n`
                    + `var ${SYNEXP} = ${CJS}helpers.staticRequire(cjs);\n`
                    + `export {${SYNEXP} as default, ${SYNEXP}};\n`,
                map: null,
                syntheticNamedExports: SYNEXP,
            };

            function deconflict(name) {
                // Deconflict the variable name across all scopes.
                // Don't save the deconflicted name in the set as we're only concerned with
                // variable conflicts in the original code - not variables introduced
                // by this plugin which relies on determinisitically producing the same
                // deconflicted names within the module.
                const nameWithPrefix = CJS + name;
                let candidate = makeLegalIdentifier(nameWithPrefix);
                for (let i = 2; potentialConflicts.has(candidate); ++i) {
                    candidate = makeLegalIdentifier(nameWithPrefix + "_" + i);
                }
                return candidate;
            }
        },
        async generateBundle(options, bundle, isWrite) {
            // Fix up names of sources in sourcemaps due to trampoline use.
            for (const k in bundle) {
                const map = bundle[k] && bundle[k].map;
                if (map && Array.isArray(map.sources) && Array.isArray(map.sourcesContent)) {
                    const requires = map.sources.filter((filename, i) => {
                        if (map.sourcesContent[i].endsWith(from_esm))
                            map.sources[i] += "-from-esm";
                        else
                            return filename.endsWith("?cjs");
                    });
                    map.sources = map.sources.map(x =>
                        requires.includes(x + "?cjs")
                            ? x + "?cjs-import"
                            : x.replace(/[?]cjs$/, ""));
                }
            }
        },
    };
};
