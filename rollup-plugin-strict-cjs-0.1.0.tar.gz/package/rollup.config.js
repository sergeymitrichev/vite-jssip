import resolve from "@rollup/plugin-node-resolve";

export default {
    input: "strict-cjs.js",
    plugins: [
        resolve()
    ],
    external: [
        "fs",
        "path",
        "@rollup/pluginutils",
        "estree-walker",
        "magic-string",
        // "is-reference" lacks cjs support and cannot be external
    ],
    output: [{
        file: "dist/index.js",
        format: "cjs",
        exports: "auto",
    }]
};
