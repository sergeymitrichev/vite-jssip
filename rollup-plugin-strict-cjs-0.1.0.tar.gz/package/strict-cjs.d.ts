export default function cjs(options?: {}): {
    name: string;
    resolveId(id: any, importer: any): Promise<any>;
    load(id: any): any;
    transform(code: any, id: any): any;
    generateBundle(options: any, bundle: any, isWrite: any): Promise<void>;
};
